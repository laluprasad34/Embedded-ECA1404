ORG 0000H

UP:
    MOV P2,#0C0H    ;0
    ACALL DELAY

    MOV P2,#0F9H    ;1
    ACALL DELAY

    MOV P2,#0A4H    ;2
    ACALL DELAY

    MOV P2,#0B0H    ;3
    ACALL DELAY

    MOV P2,#099H    ;4
    ACALL DELAY

    MOV P2,#092H    ;5
    ACALL DELAY

    MOV P2,#082H    ;6
    ACALL DELAY

    MOV P2,#0F8H    ;7
    ACALL DELAY

    MOV P2,#080H    ;8
    ACALL DELAY

    MOV P2,#090H    ;9
    ACALL DELAY

    SJMP UP         ;Repeat forever

DELAY:
    MOV R5,#10

H1:
    MOV R4,#180

H2:
    MOV R3,#255

H3:
    DJNZ R3,H3
    DJNZ R4,H2
    DJNZ R5,H1
    RET

END